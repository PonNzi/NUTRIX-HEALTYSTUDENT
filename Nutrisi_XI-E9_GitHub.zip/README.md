# Nutrisi XI-E9

Website edukasi makanan sehat dan bergizi untuk proyek XI-E9 SMA Negeri 2 Banjarmasin.

## Cara menjalankan di GitHub Pages
1. Buat repository baru di GitHub.
2. Upload `index.html`.
3. Buka **Settings → Pages**.
4. Pada Source pilih **Deploy from a branch**.
5. Pilih branch `main` dan folder `/root`.
6. Simpan dan tunggu GitHub Pages menerbitkan website.

## Catatan
Logo resmi SMA Negeri 2 Banjarmasin belum disertakan karena file logo belum diberikan. Area logo sudah disiapkan di website dan dapat diganti setelah file logo tersedia.
